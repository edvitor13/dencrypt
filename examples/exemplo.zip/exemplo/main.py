from dencrypt import (
    Crypt, # Gera Chaves Pública/Privada RSA e Simétrica Fernet 
    Encrypt, Decrypt, # Realiza En/Decriptação RSA
    EncryptFile, DecryptFile # Realiza En/Decriptação Fernet
)


input("\nAPERTE [ENTER] PARA INICIAR")

"""
# 1. Gerando as Chaves
"""
print("\n1. Gerando as Chaves")
cr = Crypt().generate_all_keys()
print("Chave Pública:\n", cr.pubkey)
print("Chave Privada:\n", cr.privkey)
print("Chave Simétrica:\n", cr.symmetrickey)

# 1.1. Salvando arquivos das chaves
print("Salvando Chaves")
cr.save_all_keys(location="keys/")

# --
input("\nAPERTE [ENTER] PARA IR PARA A PARTE 2")


"""
# 2. Criptografando Arquivos com a Chave Simétrica
"""
print("\n2. Criptografando Arquivos com a Chave Simétrica")

# 2.1. Arquivo dados1.txt
print("\ndados1.txt")
encr = EncryptFile("arquivos/dados1.txt", key="keys/symmetrickey.key")
print("Conteúdo Original:\n", encr.content)
print("Conteúdo Criptog.:\n", encr.get())

# Salvando arquivo com conteúdo criptografado
print("\nSalvando 'dados1.txt.dencrypt' em 'arquivos-crip'")
encr.save("arquivos-crip/dados1.txt.dencrypt") 

# 2.2. Arquivo dados2.csv
print("\ndados2.csv")
encr = EncryptFile("arquivos/dados2.csv", key="keys/symmetrickey.key")
print("Conteúdo Original:\n", encr.content)
print("Conteúdo Criptog.:\n", encr.get())

print("\nSalvando 'dados2.csv.dencrypt' em 'arquivos-crip'")
encr.save("arquivos-crip/dados2.csv.dencrypt")

# --
input("\nAPERTE [ENTER] PARA IR PARA A PARTE 3")


"""
# 3. Criptografando Chave Simétrica com Chave Pública RSA
"""
print("\n3. Criptografando Chave Simétrica com Chave Pública RSA")
encr = Encrypt("keys/symmetrickey.key", pubkey="keys/publickey.key")
print("Conteúdo Original:\n", encr.content)
print("Conteúdo Criptog.:\n", encr.get())

print("\nSalvando 'secreta.key' em 'arquivos-crip'")
encr.save("arquivos-crip/secreta.key")

# --
input("\nAPERTE [ENTER] PARA IR PARA A PARTE 4")


"""
# 4. Descriptografando Arquivos
"""
print("\n4. Descriptografando Arquivos")

# 4.1. Descriptografando Chave Simétrica com Chave Privada RSA
print("\n4.1. Descriptografando Chave Simétrica com Chave Privada RSA")
skey = Decrypt("arquivos-crip/secreta.key", privkey="keys/privatekey.key")
skey = skey.get()

#  4.2. Descriptografando dados1.txt.dencrypt
print("\n4.2. Descriptografando dados1.txt.dencrypt")
decr = DecryptFile("arquivos-crip/dados1.txt.dencrypt", key=skey)
decr.save("arquivos-crip/dados1.txt")

#  4.3. Descriptografando dados2.csv.dencrypt
print("\n4.3. Descriptografando dados2.csv.dencrypt")
decr = DecryptFile("arquivos-crip/dados2.csv.dencrypt", key=skey)
decr.save("arquivos-crip/dados2.csv")

# --
input("\nAPERTE [ENTER] PARA IR PARA A PARTE 5")


# 5. Realizando comparação de conteúdo
print("\n5. Realizando comparação de conteúdo")
with (
    open("arquivos/dados1.txt") as d1_original,
    open("arquivos/dados2.csv") as d2_original,
    open("arquivos-crip/dados1.txt.dencrypt") as d1_crip,
    open("arquivos-crip/dados2.csv.dencrypt") as d2_crip,
    open("arquivos-crip/dados1.txt") as d1_decrip,
    open("arquivos-crip/dados2.csv") as d2_decrip
):
    d1_original_read = d1_original.read()
    d2_original_read = d2_original.read()
    d1_crip_read = d1_crip.read()
    d2_crip_read = d2_crip.read()
    d1_decrip_read = d1_decrip.read()
    d2_decrip_read = d2_decrip.read()

    # Original com Criptografado
    v1 = d1_original_read == d1_crip_read
    v2 = d2_original_read == d2_crip_read

    # Original com Descriptografado
    v3 = d1_original_read == d1_decrip_read
    v4 = d2_original_read == d2_decrip_read

    print()
    print(f"arquivos/dados1.txt == arquivos-crip/dados1.txt.dencrypt? {v1}")
    print(f"arquivos/dados2.csv == arquivos-crip/dados2.csv.dencrypt? {v2}")
    print(f"arquivos/dados1.txt == arquivos-crip/dados1.txt? {v3}")
    print(f"arquivos/dados2.csv == arquivos-crip/dados2.csv? {v4}")

print()
input("APERTE [ENTER] PARA ENCERRAR")
